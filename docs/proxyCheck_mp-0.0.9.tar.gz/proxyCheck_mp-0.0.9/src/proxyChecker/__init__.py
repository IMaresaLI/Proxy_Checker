from proxyChecker.proxyCheck import ProxyController
